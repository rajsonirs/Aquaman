"""AquaGuard smart water leak detection demo."""
